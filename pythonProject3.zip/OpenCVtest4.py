import cv2
import mediapipe as mp
import numpy as np
import os

# MediaPipe Pose 모델 초기화
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils
pose = mp_pose.Pose(static_image_mode=True, min_detection_confidence=0.5)

# 사용할 랜드마크 리스트 (간소화)
USED_LANDMARKS = [
    mp_pose.PoseLandmark.LEFT_SHOULDER,
    mp_pose.PoseLandmark.RIGHT_SHOULDER,
    mp_pose.PoseLandmark.LEFT_ELBOW,
    mp_pose.PoseLandmark.RIGHT_ELBOW,
    mp_pose.PoseLandmark.LEFT_WRIST,
    mp_pose.PoseLandmark.RIGHT_WRIST,
]

# 커스텀 연결 정의
CUSTOM_CONNECTIONS = frozenset([
    (mp_pose.PoseLandmark.LEFT_SHOULDER, mp_pose.PoseLandmark.RIGHT_SHOULDER),
    (mp_pose.PoseLandmark.LEFT_SHOULDER, mp_pose.PoseLandmark.LEFT_ELBOW),
    (mp_pose.PoseLandmark.RIGHT_SHOULDER, mp_pose.PoseLandmark.RIGHT_ELBOW),
    (mp_pose.PoseLandmark.LEFT_ELBOW, mp_pose.PoseLandmark.LEFT_WRIST),
    (mp_pose.PoseLandmark.RIGHT_ELBOW, mp_pose.PoseLandmark.RIGHT_WRIST),
])

# 이미지 경로
image_path = "img.jpg"

# 파일 존재 여부 확인
if not os.path.isfile(image_path):
    print(f"파일이 존재하지 않습니다: {image_path}")
else:
    # 이미지 로드
    image = cv2.imread(image_path)

    if image is None:
        print(f"이미지를 불러올 수 없습니다: {image_path}")
    else:
        print("이미지를 성공적으로 불러왔습니다.")

        # 이미지 처리
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # 포즈 검출
        results = pose.process(image_rgb)

        # 스켈레톤 그리기
        if results.pose_landmarks:
            h, w, _ = image.shape

            # 목 키포인트 계산 (양 어깨의 중간점)
            left_shoulder = results.pose_landmarks.landmark[mp_pose.PoseLandmark.LEFT_SHOULDER]
            right_shoulder = results.pose_landmarks.landmark[mp_pose.PoseLandmark.RIGHT_SHOULDER]
            neck_x = (left_shoulder.x + right_shoulder.x) / 2
            neck_y = (left_shoulder.y + right_shoulder.y) / 2
            neck_z = (left_shoulder.z + right_shoulder.z) / 2

            # 머리 뒤 키포인트 계산 (메인 키포인트)
            main_head_x = neck_x
            main_head_y = neck_y - 0.2  # 목에서 더 위로 이동
            main_head_z = neck_z

            # 원본 이미지에 스켈레톤 그리기
            for landmark in USED_LANDMARKS:
                landmark_point = results.pose_landmarks.landmark[landmark]
                cx, cy = int(landmark_point.x * w), int(landmark_point.y * h)
                cv2.circle(image, (cx, cy), 5, (0, 255, 0), -1)

            # 목 키포인트 그리기
            neck_cx, neck_cy = int(neck_x * w), int(neck_y * h)
            cv2.circle(image, (neck_cx, neck_cy), 5, (0, 255, 0), -1)

            # 메인 키포인트 (머리 뒤) 그리기
            main_head_cx, main_head_cy = int(main_head_x * w), int(main_head_y * h)
            cv2.circle(image, (main_head_cx, main_head_cy), 8, (0, 0, 255), -1)  # 빨간색, 더 큰 원으로 표시

            # 기존 연결선 그리기
            for connection in CUSTOM_CONNECTIONS:
                start_point = results.pose_landmarks.landmark[connection[0]]
                end_point = results.pose_landmarks.landmark[connection[1]]
                start_x, start_y = int(start_point.x * w), int(start_point.y * h)
                end_x, end_y = int(end_point.x * w), int(end_point.y * h)
                cv2.line(image, (start_x, start_y), (end_x, end_y), (255, 0, 0), 2)

            # 메인 키포인트(머리 뒤)와 목 연결선 그리기
            cv2.line(image, (main_head_cx, main_head_cy), (neck_cx, neck_cy), (255, 0, 0), 3)  # 더 두꺼운 선으로 표시

            # 목과 어깨 연결선 그리기
            cv2.line(image, (neck_cx, neck_cy), (int(left_shoulder.x * w), int(left_shoulder.y * h)), (255, 0, 0), 2)
            cv2.line(image, (neck_cx, neck_cy), (int(right_shoulder.x * w), int(right_shoulder.y * h)), (255, 0, 0), 2)

            # 결과 저장
            output_path = "custom_skeleton_with_main_head_point.jpg"
            cv2.imwrite(output_path, image)
            print(f"메인 키포인트가 포함된 커스텀 스켈레톤 이미지가 저장되었습니다: {output_path}")
        else:
            print("이미지에서 사람을 찾을 수 없습니다.")

# 리소스 해제
pose.close()