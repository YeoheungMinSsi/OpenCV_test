import cv2
import mediapipe as mp
import numpy as np
import os

# MediaPipe Pose 모델 초기화
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils
pose = mp_pose.Pose(static_image_mode=True, min_detection_confidence=0.5)

# 이미지 경로
image_path = "img.jpg"

# 파일 존재 여부 확인
if not os.path.isfile(image_path):
    print(f"파일이 존재하지 않습니다: {image_path}")
else:
    # 이미지 로드
    image = cv2.imread(image_path)

    if image is None:
        print(f"이미지를 불러올 수 없습니다: {image_path}")
    else:
        print("이미지를 성공적으로 불러왔습니다.")

        # 이미지 처리
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # 포즈 검출
        results = pose.process(image_rgb)

        # 스켈레톤 그리기
        if results.pose_landmarks:
            # 원본 이미지에 스켈레톤 그리기
            mp_drawing.draw_landmarks(
                image,
                results.pose_landmarks,
                mp_pose.POSE_CONNECTIONS,
                mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2),  # 녹색으로 키포인트 표시
                mp_drawing.DrawingSpec(color=(255, 0, 0), thickness=2)  # 파란색으로 선 표시
            )

            # 결과 저장
            output_path = "skeleton_on_image_output.jpg"
            cv2.imwrite(output_path, image)
            print(f"스켈레톤이 표시된 이미지가 저장되었습니다: {output_path}")
        else:
            print("이미지에서 사람을 찾을 수 없습니다.")

# 리소스 해제
pose.close()