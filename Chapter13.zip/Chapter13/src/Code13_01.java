import org.opencv.core.Core;

public class Code13_01 {
	public static void main(String[] args) {
        System.out.println("설치된 OpenCV 버전 ==> " + Core.VERSION);
	}
}